# Hero Inline Embed Handoff

Use this file when the website should load the GHL form inline on the page:

- `Forms for GHL/hero-inline-embed.html`

What it does:
- Loads the GHL form `kxrHpS9bX16nzkIbr2py`
- Uses the `INLINE` layout
- Always shows
- Never deactivates automatically

Notes:
- This is the inline GHL embed version of the hero form.
- It is separate from the custom webhook-based hero replacement file.
- It is also separate from the popup embed file.
- Keep the embed attributes exactly as-is unless the live GHL form settings change.
