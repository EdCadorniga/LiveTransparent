# Hero Popup Embed Handoff

Use this file when the website should also load the GHL popup form:

- `Forms for GHL/hero-popup-embed.html`

What it does:
- Loads the same GHL form used for the hero booking flow:
  `kxrHpS9bX16nzkIbr2py`
- Uses the popup layout.
- Triggers after `4` seconds.
- Stops showing after the lead is collected.

Notes:
- This is separate from the custom hero replacement form file.
- The popup behavior is controlled by GHL's embed runtime, not the local hero webhook form.
- Keep the embed attributes exactly as-is unless the popup timing or activation rules need to change.
